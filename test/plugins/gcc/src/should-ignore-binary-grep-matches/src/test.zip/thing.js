goog.provide('thing');
